# Portifolio
 Projetos profissionais de Assessoria de BI e Websites.

 Este portifólio tem o objetivo de apresentar os produtos desenvolvidos para a Assessoria de Business Intelligence e Websites.
 
 Estes produtos compreendem o modelo de negócio da Thyago Fonseca, que tem o objetivo de melhorar o trabalho de pessoas que produzem dados, sejam eles estruturados ou não, mas não extraem todo o potencial de conhecimento deles, gerando-os tanto em sistemas eletrônicos de gestão do negócio, Excel/LibreOffice, ou até mesmo Instagram.

 Se você cliente tem problemas quanto o que necessário para realizar todas essas tarefas, ou não é viável para você criar um processo interno ao seu negócio nesse sentido, tudo apenas para ter o conhecimento necessário para tomar melhores decisões, apliar sua visão do negócio, criar oportunidades de crescimento ou ampliação de seu negócio, e principalmente, monitorar seus dados de forma clara, visual, e fácil.
